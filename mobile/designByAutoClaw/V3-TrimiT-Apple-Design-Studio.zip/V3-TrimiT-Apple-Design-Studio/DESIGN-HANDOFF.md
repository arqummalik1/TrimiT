# V3 TrimiT Apple Design Studio.html implementation handoff

This archive is the source of truth for implementing the exported Design Expert prototype.

## Entry
- Primary file: `Users/arqummalik/Software-Development/Trimit/TrimiT/design/V3 TrimiT Apple Design Studio.html`
- Machine-readable manifest: `DESIGN-MANIFEST.json`

## Source Files
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/V3 TrimiT Apple Design Studio.html`
- `tmp/check_theme.js`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/screenshot_check.png`
- `Users/arqummalik/Software-Development/Trimit/TrimiT/design/V3 TrimiT Apple Design Studio.html`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/check2.js`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/wm_on_white.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/wordmark_gold.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/wordmark_dark.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/wordmark_black.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/tmark_sm.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/.openclaw/tmp/v3/square_sm.png`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/V2 TrimiT Design Studio.html`
- `Users/arqummalik/.openclaw-autoclaw/agents/auto-coder/workspace/V1 TrimiT Design Direction.html`

## Implementation Checklist
1. Inspect `Users/arqummalik/Software-Development/Trimit/TrimiT/design/V3 TrimiT Apple Design Studio.html` and `DESIGN-MANIFEST.json` before coding.
2. Preserve the exported typography, colors, spacing, radius, shadows, motion and responsive behavior.
3. Keep every visible interaction state that appears in the prototype.
4. Remove Design Expert preview chrome from production code.
5. Validate the implementation at desktop, tablet and mobile widths before handoff.
